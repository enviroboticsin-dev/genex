package com.envirobotics.inventory
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.*
import retrofit2.Call
data class Product(val id:Int, val name:String?, val barcode:String?, val quantity:Int?)
interface ApiService {
    @GET("scan.php") fun scan(@Query("barcode") barcode:String): Call<Product>
    @FormUrlEncoded @POST("add_stock.php") fun addStock(@Field("barcode") barcode:String, @Field("qty") qty:Int): Call<java.util.Map<String,Any>>
    @FormUrlEncoded @POST("remove_stock.php") fun removeStock(@Field("barcode") barcode:String, @Field("qty") qty:Int): Call<java.util.Map<String,Any>>
}
object ApiClient {
    private val retrofit = Retrofit.Builder().baseUrl("http://192.168.1.103/public/api/").addConverterFactory(GsonConverterFactory.create()).build()
    val service: ApiService = retrofit.create(ApiService::class.java)
}
