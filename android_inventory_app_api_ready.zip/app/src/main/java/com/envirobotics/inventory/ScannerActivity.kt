package com.envirobotics.inventory
import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.envirobotics.inventory.databinding.ActivityScannerBinding
import com.google.zxing.integration.android.IntentIntegrator
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
class ScannerActivity : AppCompatActivity() {
    private lateinit var binding: ActivityScannerBinding
    private val requestPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()){ granted ->
        if (granted) startScan() else AlertDialog.Builder(this).setMessage("Camera permission is required").setPositiveButton("OK", null).show()
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityScannerBinding.inflate(layoutInflater)
        setContentView(binding.root)
        binding.btnStartScan.setOnClickListener {
            val pm = ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
            if (pm == PackageManager.PERMISSION_GRANTED) startScan()
            else requestPermission.launch(Manifest.permission.CAMERA)
        }
    }
    private fun startScan(){
        val integrator = IntentIntegrator(this)
        integrator.setDesiredBarcodeFormats(IntentIntegrator.ALL_CODE_TYPES)
        integrator.setPrompt("Scan a barcode")
        integrator.setBeepEnabled(true)
        integrator.setOrientationLocked(false)
        integrator.captureActivity = com.journeyapps.barcodescanner.CaptureActivity::class.java
        integrator.initiateScan()
    }
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        val result = IntentIntegrator.parseActivityResult(requestCode, resultCode, data)
        if (result != null && result.contents != null) {
            val code = result.contents
            showActionDialog(code)
        }
    }
    private fun showActionDialog(code: String){
        val items = arrayOf("Add Stock", "Remove Stock")
        AlertDialog.Builder(this)
            .setTitle("Scanned: $code")
            .setItems(items){ d, which ->
                when(which){
                    0 -> openQtyDialog(code, "add")
                    1 -> openQtyDialog(code, "remove")
                }
            }.show()
    }
    private fun openQtyDialog(code: String, action: String){
        val input = android.widget.EditText(this)
        input.inputType = android.text.InputType.TYPE_CLASS_NUMBER
        AlertDialog.Builder(this)
            .setTitle("Quantity")
            .setView(input)
            .setPositiveButton("OK"){ dialog, _->
                val q = input.text.toString().toIntOrNull() ?: 0
                if(q <= 0) return@setPositiveButton
                if(action == "add") {
                    ApiClient.service.addStock(code, q).enqueue(object: Callback<java.util.Map<String,Any>>{
                        override fun onResponse(call: Call<java.util.Map<String,Any>>, response: Response<java.util.Map<String,Any>>) {
                            AlertDialog.Builder(this@ScannerActivity).setMessage("Added $q units").setPositiveButton("OK",null).show()
                        }
                        override fun onFailure(call: Call<java.util.Map<String,Any>>, t: Throwable) { AlertDialog.Builder(this@ScannerActivity).setMessage("API error: " + t.message).setPositiveButton("OK",null).show() }
                    })
                } else {
                    ApiClient.service.removeStock(code, q).enqueue(object: Callback<java.util.Map<String,Any>>{
                        override fun onResponse(call: Call<java.util.Map<String,Any>>, response: Response<java.util.Map<String,Any>>) {
                            AlertDialog.Builder(this@ScannerActivity).setMessage("Removed $q units").setPositiveButton("OK",null).show()
                        }
                        override fun onFailure(call: Call<java.util.Map<String,Any>>, t: Throwable) { AlertDialog.Builder(this@ScannerActivity).setMessage("API error: " + t.message).setPositiveButton("OK",null).show() }
                    })
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }
}
